import React from 'react';
import {
  // useDispatch,
  useSelector
} from 'react-redux';
import { useParams } from 'react-router-dom';
import ShallowRenderer from 'react-test-renderer/shallow';
import ActivateRewards,
{
  // ActivateRewardsCard,
  TermsAndConditions,
  Verify,
  Request,
  SuccessfullCard
} from '../ActivateRewards';

jest.mock('../actions', () => ({
  activateReward: jest.fn(),
  verifyOtp: jest.fn(),
  fetchStatusRewards: jest.fn(),
  resendOtp: jest.fn(),
  fetchDataUser: jest.fn(),
}));

const payDetail = [
  {
    detail: 'BIAYA INDIHOME',
    namount: 35000,
  },
  {
    detail: 'PAJAK',
    namount: 5000,
  },
];

useSelector.mockImplementation((fn) => {
  fn({});
  return {
    payId: '954001805220',
    payDate: '20191015',
    payTime: '214530',
    payLocation: 'FPC FINNET KOPEGTEL',
    payDetail,
    totalAmount: 45000,
  };
});

describe('src/pages/ActivateRewards', () => {
  test('render activateRewards', () => {
    const shallow = new ShallowRenderer();
    const tree = shallow.render(<ActivateRewards />);
    expect(tree).toMatchSnapshot();
  });

  test('render activateRewards success', () => {
    const shallow = new ShallowRenderer();
    const tree = shallow.render(<ActivateRewards />);
    expect(tree).toMatchSnapshot();


    useParams.mockImplementationOnce(() => ({ page: 'success' }));
    const result = ActivateRewards();
    expect(result.props.children.type).toBe(SuccessfullCard);
  });

  test('render activateRewards request', () => {
    const shallow = new ShallowRenderer();
    const tree = shallow.render(<ActivateRewards />);
    expect(tree).toMatchSnapshot();


    useParams.mockImplementationOnce(() => ({ page: 'request' }));
    const result = ActivateRewards();
    expect(result.props.children.type).toBe(Request);
  });

  test('render activateRewards verify', () => {
    const shallow = new ShallowRenderer();
    const tree = shallow.render(<ActivateRewards />);
    expect(tree).toMatchSnapshot();


    useParams.mockImplementationOnce(() => ({ page: 'verify' }));
    const result = ActivateRewards();
    expect(result.props.children.type).toBe(Verify);
  });

  test('render activateRewards verify', () => {
    const shallow = new ShallowRenderer();
    const tree = shallow.render(<ActivateRewards />);
    expect(tree).toMatchSnapshot();


    useParams.mockImplementationOnce(() => ({ page: 'tnc' }));
    const result = ActivateRewards();
    expect(result.props.children.type).toBe(TermsAndConditions);
  });


  test('Activate reward', () => {
    const result = {
      'isLoading': true,
      'message': '',
      'status': '',
      'mobileNumber': '',
      'deadlineOTP': 0,
      'terms': '',
      'category': [],
      'countOTP': 2,
      'isActivated': '',
    };
    useSelector.mockImplementationOnce(fn => {
      fn({});
      return { result };
    });

    const shallow = new ShallowRenderer();
    const tree = shallow.render(<ActivateRewards />);
    expect(tree).toMatchSnapshot();
  });
});
