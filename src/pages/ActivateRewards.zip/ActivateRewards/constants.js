export const FAILED = 'ActivateRewards/failed';
export const FETCHED = 'ActivateRewards/fetched';
export const LOADING = 'ActivateRewards/loading';
export const RESET = 'ActivateRewards/reset';
export const STATUS = 'ActivateRewards/status';
export const USER = 'ActivateRewards/user';
export const COUNTER = 'ActivateRewards/counter';
