export { default } from './ActivateRewards';
